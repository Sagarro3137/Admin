
package com.dev.sms2webhook

import android.content.Context
import android.content.SharedPreferences

class Prefs(ctx: Context) {
    private val p: SharedPreferences = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    var url: String
        get() = p.getString("url", "") ?: ""
        set(v) = p.edit().putString("url", v).apply()
    var senders: String
        get() = p.getString("senders", "HDFCBK,AXISBK,SBIINB,ICICIB,KOTAKB,UPI") ?: ""
        set(v) = p.edit().putString("senders", v).apply()
    var keywords: String
        get() = p.getString("keywords", "credited,INR,UPI,received") ?: ""
        set(v) = p.edit().putString("keywords", v).apply()
    var foreground: Boolean
        get() = p.getBoolean("foreground", true)
        set(v) = p.edit().putBoolean("foreground", v).apply()
}
