
package com.dev.sms2webhook

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Telephony
import android.telephony.SmsMessage

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val bundle: Bundle? = intent.extras
            val pdus = bundle?.get("pdus") as? Array<*>
            if (pdus != null) {
                val msgs = pdus.mapNotNull {
                    SmsMessage.createFromPdu(it as ByteArray, bundle.getString("format"))
                }
                val body = msgs.joinToString("\n") { it.messageBody }
                val sender = msgs.firstOrNull()?.displayOriginatingAddress ?: ""
                Forwarder.enqueue(context, body, sender)
            }
        }
    }
}
