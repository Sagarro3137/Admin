
package com.dev.sms2webhook

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder

class KeepAliveService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val chanId = "keepalive"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(chanId, "SMS → Webhook", NotificationManager.IMPORTANCE_MIN))
        }
        val n: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, chanId).setContentTitle("SMS → Webhook running").setSmallIcon(android.R.drawable.stat_sys_upload).build()
        } else {
            Notification()
        }
        startForeground(1, n)
        return START_STICKY
    }
}
