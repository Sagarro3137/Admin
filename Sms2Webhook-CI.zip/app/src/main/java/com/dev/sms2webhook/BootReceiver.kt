
package com.dev.sms2webhook

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = Prefs(context)
        if (prefs.foreground) {
            context.startService(Intent(context, KeepAliveService::class.java))
        }
    }
}
