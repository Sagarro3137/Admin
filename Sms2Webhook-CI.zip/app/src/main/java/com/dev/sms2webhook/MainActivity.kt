
package com.dev.sms2webhook

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    private lateinit var etUrl: EditText
    private lateinit var etSenders: EditText
    private lateinit var etKeywords: EditText
    private lateinit var tvLog: TextView
    private lateinit var swForeground: Switch

    private val reqPerms = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etUrl = findViewById(R.id.etUrl)
        etSenders = findViewById(R.id.etSenders)
        etKeywords = findViewById(R.id.etKeywords)
        tvLog = findViewById(R.id.tvLog)
        swForeground = findViewById(R.id.swForeground)

        val prefs = Prefs(this)
        etUrl.setText(prefs.url)
        etSenders.setText(prefs.senders)
        etKeywords.setText(prefs.keywords)
        swForeground.isChecked = prefs.foreground

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            prefs.url = etUrl.text.toString().trim()
            prefs.senders = etSenders.text.toString().trim()
            prefs.keywords = etKeywords.text.toString().trim()
            prefs.foreground = swForeground.isChecked
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            if (prefs.foreground) {
                startService(Intent(this, KeepAliveService::class.java))
            } else {
                stopService(Intent(this, KeepAliveService::class.java))
            }
        }

        findViewById<Button>(R.id.btnTest).setOnClickListener {
            val body = "Test credited INR 123.45 via UPI"
            Forwarder.sendNow(this, body, "TESTSENDER")
            tvLog.text = "Test sent to ${prefs.url}"
        }

        askPerms()
    }

    private fun askPerms() {
        val list = mutableListOf(
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS
        )
        if (Build.VERSION.SDK_INT >= 33) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        reqPerms.launch(list.toTypedArray())

        // Battery optimization
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
                if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    intent.data = Uri.parse("package:$packageName")
                    startActivity(intent)
                }
            } catch (_: Exception) {}
        }
    }
}
