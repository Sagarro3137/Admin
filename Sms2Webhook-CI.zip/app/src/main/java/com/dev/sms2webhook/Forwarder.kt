
package com.dev.sms2webhook

import android.content.Context
import android.util.Log
import androidx.work.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object Forwarder {
    fun enqueue(ctx: Context, body: String, sender: String) {
        val prefs = Prefs(ctx)
        // Filters
        val okSender = prefs.senders.split(",").map { it.trim().uppercase() }.any { it.isNotEmpty() && sender.uppercase().contains(it) }
        val okKeyword = prefs.keywords.split(",").map { it.trim().lowercase() }.any { it.isNotEmpty() && body.lowercase().contains(it) }
        if (!okSender || !okKeyword) return

        val data = workDataOf("body" to body, "sender" to sender)
        val req = OneTimeWorkRequestBuilder<ForwardWorker>()
            .setInputData(data)
            .setBackoffCriteria(BackoffPolicy.LINEAR, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(ctx).enqueue(req)
    }

    fun sendNow(ctx: Context, body: String, sender: String) {
        val worker = ForwardWorker(appContext = ctx, workerParams = TestParams())
        worker.testSend(body, sender)
    }
}

class TestParams: WorkerParameters(
    java.util.UUID.randomUUID(),
    Data.EMPTY,
    java.util.Collections.emptyList(),
    WorkerParameters.RuntimeExtras(),
    1,
    androidx.work.impl.utils.taskexecutor.TaskExecutor { command -> command.run() },
    androidx.work.WorkerFactory()
)

class ForwardWorker(appContext: Context, workerParams: WorkerParameters) : Worker(appContext, workerParams) {

    override fun doWork(): Result {
        val prefs = Prefs(applicationContext)
        val url = prefs.url
        if (url.isBlank()) return Result.success()

        val body = inputData.getString("body") ?: ""
        val sender = inputData.getString("sender") ?: ""
        return try {
            val client = OkHttpClient()
            val json = JSONObject()
            json.put("from", sender)
            json.put("body", body)
            json.put("ts", System.currentTimeMillis())

            val req = Request.Builder()
                .url(url)
                .post(json.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()

            client.newCall(req).execute().use { res ->
                if (!res.isSuccessful) Log.w("Forwarder", "HTTP "+res.code)
            }
            Result.success()
        } catch (e: Exception) {
            Log.e("Forwarder", "send error", e)
            Result.retry()
        }
    }

    // for MainActivity test button
    fun testSend(body: String, sender: String) {
        val prefs = Prefs(applicationContext)
        val url = prefs.url
        if (url.isBlank()) return
        try {
            val client = OkHttpClient()
            val json = JSONObject()
            json.put("from", sender)
            json.put("body", body)
            json.put("ts", System.currentTimeMillis())

            val req = Request.Builder()
                .url(url)
                .post(json.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()
            client.newCall(req).execute().use { }
        } catch (_: Exception) {}
    }
}
